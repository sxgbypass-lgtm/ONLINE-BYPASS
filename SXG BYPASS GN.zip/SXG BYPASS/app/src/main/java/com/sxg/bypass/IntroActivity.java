package com.sxg.bypass;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.ViewPager2;

public class IntroActivity extends AppCompatActivity {

    private ViewPager2 viewPager;
    private TextView btnSkip, btnNext;
    private View dot1, dot2;
    private boolean navigationInProgress = false;
    private static final String STATE_INTRO_PAGE = "state_intro_page";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        SharedPreferences prefs = getSharedPreferences("AsurPrefs", MODE_PRIVATE);
        boolean introShown = prefs.getBoolean("introShown", false);

        // Only redirect when this is a fresh launch. If Android recreates this
        // Activity (for example after rotation), restore the in-progress intro.
        if (new NativeBridge().shouldRedirectIntro(introShown, savedInstanceState == null)) {
            openMainActivity();
            return;
        }

        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        );

        setContentView(R.layout.activity_intro);

        viewPager = findViewById(R.id.viewPager);
        btnSkip = findViewById(R.id.btnSkip);
        btnNext = findViewById(R.id.btnNext);
        dot1 = findViewById(R.id.dot1);
        dot2 = findViewById(R.id.dot2);

        int[] images = {
                R.drawable.welcome_screen,
                R.drawable.setup_guide
        };

        IntroAdapter adapter = new IntroAdapter(images);
        viewPager.setAdapter(adapter);

        viewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                if (position == 0) {
                    dot1.setBackgroundResource(R.drawable.dot_active);
                    dot2.setBackgroundResource(R.drawable.dot_inactive);
                    btnNext.setText("NEXT");
                } else {
                    dot1.setBackgroundResource(R.drawable.dot_inactive);
                    dot2.setBackgroundResource(R.drawable.dot_active);
                    btnNext.setText("FINISH");
                }
            }
        });

        if (savedInstanceState != null) {
            int savedPage = savedInstanceState.getInt(STATE_INTRO_PAGE, 0);
            viewPager.setCurrentItem(Math.max(0, Math.min(savedPage, images.length - 1)), false);
        }

        btnSkip.setOnClickListener(v -> goToMainActivity());

        btnNext.setOnClickListener(v -> {
            if (viewPager.getCurrentItem() == 0) {
                viewPager.setCurrentItem(1);
            } else {
                goToMainActivity();
            }
        });
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        if (viewPager != null) {
            outState.putInt(STATE_INTRO_PAGE, viewPager.getCurrentItem());
        }
        super.onSaveInstanceState(outState);
    }

    private void goToMainActivity() {
        if (navigationInProgress) return;
        navigationInProgress = true;

        SharedPreferences prefs = getSharedPreferences("AsurPrefs", MODE_PRIVATE);
        // Commit before navigation so the one-time flag survives immediate process death.
        prefs.edit().putBoolean("introShown", true).commit();
        openMainActivity();
    }

    private void openMainActivity() {
        startActivity(new Intent(IntroActivity.this, MainActivity.class));
        finish();
    }
}