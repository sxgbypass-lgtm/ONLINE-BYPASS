package com.sxg.bypass;

/** JNI entry points for native business rules. Android UI/lifecycle stays in Java. */
public class NativeBridge {
    static { System.loadLibrary("sxg"); }

    public native String getApiUrl();
    public native String getAimZipUrl();
    public native String getTelegramUrl();
    public native long parseExpiryMillis(String value);
    public native boolean isSessionExpired(long expiryMillis, long nowMillis);
    public native String normalizeLoginKey(String value);
    public native String generateSerial(String key, String androidId, String model, String brand);
    public native boolean shouldClearHomeSession(boolean isLoggedIn, boolean hasKey, long expiryMillis, long nowMillis);
    public native boolean shouldRedirectIntro(boolean introShown, boolean freshLaunch);
}
