
package com.sxg.bypass;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.PixelFormat;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.sxg.bypass.databinding.ActivityMainBinding;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.TimeUnit;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import rikka.shizuku.Shizuku;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;

    private static final int SHIZUKU_PERMISSION_REQUEST_CODE = 1001;
    private static final String PKG_BGMI = "com.pubg.imobile";
    private static final String PREFS_GAME = "sxg_preferences";
    private static final String KEY_SELECTED_GAME = "selected_game_package";

    private final NativeBridge nativeBridge = new NativeBridge();
    private OkHttpClient httpClient;
    private Handler pingHandler;

    private WindowManager overlayWindowManager;
    private View overlayView;
    private WindowManager.LayoutParams overlayParams;
    private boolean overlayShowing = false;
    private AlertDialog loadingDialog;

    private final Handler timerHandler = new Handler(Looper.getMainLooper());
    private Runnable timerRunnable;

    private boolean pendingDownloadAfterPermission = false;
    private boolean logoutInProgress = false;

    private static final long BACK_PRESS_INTERVAL = 2000L;
    private long lastBackPressTime = 0L;
    private Toast backToast;

    private final Shizuku.OnRequestPermissionResultListener permissionResultListener =
            (requestCode, grantResult) -> {
                if (requestCode == SHIZUKU_PERMISSION_REQUEST_CODE) {
                    runOnUiThread(() -> {
                        if (grantResult == PackageManager.PERMISSION_GRANTED) {
                            Toast.makeText(this,
                                    "Shizuku permission granted!",
                                    Toast.LENGTH_SHORT).show();

                            if (pendingDownloadAfterPermission) {
                                pendingDownloadAfterPermission = false;
                                downloadAndExtractAim();
                            }
                        } else {
                            pendingDownloadAfterPermission = false;
                            Toast.makeText(this,
                                    "Permission denied! Allow in Shizuku.",
                                    Toast.LENGTH_LONG).show();
                        }
                    });
                }
            };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        SharedPreferences prefs =
                getSharedPreferences("AsurPrefs", MODE_PRIVATE);

        String savedKey = prefs.getString("userKey", "");
        long savedExpiry = prefs.getLong("expiryDate", 0L);

        boolean sessionExpired = nativeBridge.isSessionExpired(
                savedExpiry, System.currentTimeMillis());

        if (savedKey.isEmpty() || sessionExpired) {
            if (!savedKey.isEmpty() && sessionExpired) {
                prefs.edit()
                        .remove("isLoggedIn")
                        .remove("expiryDate")
                        .remove("encKey")
                        .remove("userKey")
                        .remove("serialUuid")
                        .apply();

                Toast.makeText(this,
                        "Key Expired! Please login again.",
                        Toast.LENGTH_LONG).show();
            }

            Intent loginIntent = new Intent(this, LoginActivity.class);
            loginIntent.addFlags(
                    Intent.FLAG_ACTIVITY_CLEAR_TOP
                            | Intent.FLAG_ACTIVITY_NEW_TASK);

            startActivity(loginIntent);
            finish();
            return;
        }

        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setupBackPressHandler();
        setupBottomNavigation();

        binding.btnLaunch.setOnClickListener(v -> launchGame());
        binding.btnAimAssist.setOnClickListener(v -> downloadAndExtractAim());

        View changeSelectedGame = findViewById(R.id.btnChangeSelectedGame);
        if (changeSelectedGame != null) {
            changeSelectedGame.setOnClickListener(v ->
                    startActivity(new Intent(MainActivity.this, SelectGameActivity.class)));
        }
        refreshSelectedGameCard();

        View btnTelegramIcon = findViewById(R.id.btnTelegramIcon);
        if (btnTelegramIcon != null) {
            btnTelegramIcon.setOnClickListener(v -> openTelegram());
        }

        Shizuku.addRequestPermissionResultListener(permissionResultListener);

        startExpiryTimer();

        httpClient = new OkHttpClient.Builder()
                .connectTimeout(15, TimeUnit.SECONDS)
                .readTimeout(15, TimeUnit.SECONDS)
                .build();

        startHeartbeat();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (binding != null) refreshSelectedGameCard();
    }

    private void refreshSelectedGameCard() {
        TextView nameView = findViewById(R.id.tvSelectedGameName);
        TextView detailsView = findViewById(R.id.tvSelectedGameDetails);
        ImageView iconView = findViewById(R.id.ivSelectedGameIcon);
        if (nameView == null || detailsView == null) return;

        String[][] knownGames = {
                {"BGMI Mobile (IN)", "com.pubg.imobile", "bgmi_in"},
                {"PUBG Mobile (KR)", "com.pubg.krmobile", "pubg_kr"},
                {"PUBG Mobile (GL)", "com.tencent.ig", "pubg_gl"},
                {"PUBG Mobile (TW)", "com.rekoo.pubgm", "pubg_tw"},
                {"PUBG Mobile (VNG)", "com.vng.pubgmobile", "pubg_vng"},
                {"BGMI Lite (IN)", "com.krafton.bgmilite", "bgmi_lite"},
                {"PUBG Lite (GL)", "com.tencent.igfit", "pubg_lite"}
        };

        String selectedPackage = getSharedPreferences(PREFS_GAME, MODE_PRIVATE)
                .getString(KEY_SELECTED_GAME, PKG_BGMI);
        String selectedName = "Unknown game";
        String selectedIconName = null;
        for (String[] game : knownGames) {
            if (game[1].equals(selectedPackage)) {
                selectedName = game[0];
                selectedIconName = game[2];
                break;
            }
        }
        nameView.setText(selectedName);

        if (iconView != null) {
            int iconRes = selectedIconName == null ? 0
                    : getResources().getIdentifier(selectedIconName, "drawable", getPackageName());
            iconView.setImageResource(iconRes != 0 ? iconRes : R.drawable.ic_gamepad);
        }

        try {
            android.content.pm.PackageInfo info =
                    getPackageManager().getPackageInfo(selectedPackage, 0);
            String version = info.versionName;
            if (version == null || version.trim().isEmpty()) {
                version = android.os.Build.VERSION.SDK_INT >= 28
                        ? String.valueOf(info.getLongVersionCode())
                        : String.valueOf(info.versionCode);
            }
            detailsView.setText("Version: " + version + "  •  Installed");
            detailsView.setTextColor(android.graphics.Color.rgb(74, 222, 128));
        } catch (PackageManager.NameNotFoundException e) {
            detailsView.setText("Not installed");
            detailsView.setTextColor(android.graphics.Color.rgb(167, 139, 250));
        }
    }

    private void setupBottomNavigation() {
        View navHome = findViewById(R.id.navHome);
        View navSelectGame = findViewById(R.id.navSelectGame);
        View navSetup = findViewById(R.id.navSetup);
        View navSettings = findViewById(R.id.navSettings);

        setActiveBottomNavigation(R.id.navHome);
        if (navHome != null) navHome.setOnClickListener(v -> { /* Already on Home. */ });
        if (navSelectGame != null) navSelectGame.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, SelectGameActivity.class)));
        if (navSetup != null) navSetup.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, SetupActivity.class)));
        if (navSettings != null) navSettings.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, SettingsActivity.class)));
    }

    private void setActiveBottomNavigation(int activeId) {
        int[] ids = {R.id.navHome, R.id.navSelectGame, R.id.navSetup, R.id.navSettings};
        for (int id : ids) {
            View item = findViewById(id);
            if (item == null) continue;
            boolean active = id == activeId;
            item.setBackgroundResource(active ? R.drawable.bg_bottom_nav_selected
                    : android.R.color.transparent);
            if (item instanceof TextView) {
                ((TextView) item).setTextColor(android.graphics.Color.parseColor(
                        active ? "#FFFFFF" : "#C7B8E8"));
            }
        }
    }

    private void startHeartbeat() {
        pingHandler = new Handler(Looper.getMainLooper());

        Runnable pingRunnable = new Runnable() {
            @Override
            public void run() {
                checkServerStatus();
                pingHandler.postDelayed(this, 3 * 60 * 1000);
            }
        };

        pingHandler.postDelayed(pingRunnable, 10000);
    }

    private void checkServerStatus() {
        SharedPreferences prefs =
                getSharedPreferences("AsurPrefs", MODE_PRIVATE);

        String userKey = prefs.getString("userKey", "");
        String serialUuid = prefs.getString("serialUuid", "");

        if (userKey.isEmpty() || serialUuid.isEmpty()
                || httpClient == null) {
            return;
        }

        RequestBody formBody = new FormBody.Builder()
                .add("game", "PUBG")
                .add("user_key", userKey)
                .add("serial", serialUuid)
                .build();

        Request request = new Request.Builder()
                .url(nativeBridge.getApiUrl())
                .post(formBody)
                .addHeader("Accept", "application/json")
                .addHeader("Charset", "UTF-8")
                .addHeader("User-Agent", "")
                .build();

        httpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(
                    @NonNull Call call,
                    @NonNull IOException e) {
                Log.e("HEARTBEAT",
                        "Network Error: " + e.getMessage());
            }

            @Override
            public void onResponse(
                    @NonNull Call call,
                    @NonNull Response response) throws IOException {

                String responseBody;

                try (Response res = response) {
                    responseBody = res.body() != null
                            ? res.body().string()
                            : "";
                }

                runOnUiThread(() -> {
                    try {
                        JSONObject json = new JSONObject(responseBody);
                        boolean status = json.optBoolean("status", false);

                        if (!status) {
                            String reason = json.optString(
                                    "reason",
                                    "Your key has been blocked by Admin!");

                            forceLogout(reason);
                        } else {
                            JSONObject data = json.has("data")
                                    ? json.getJSONObject("data")
                                    : json;

                            String rawExp = data.optString("EXP", "");

                            if (!rawExp.isEmpty()) {
                                try {
                                    long expiry =
                                            nativeBridge.parseExpiryMillis(rawExp);

                                    if (expiry > 0L) {
                                        prefs.edit()
                                                .putLong("expiryDate", expiry)
                                                .apply();
                                    }
                                } catch (Exception ignored) {
                                }
                            }
                        }
                    } catch (Exception e) {
                        Log.e("HEARTBEAT",
                                "Parse Error: " + responseBody, e);
                    }
                });
            }
        });
    }

    private void forceLogout(String reason) {
        if (logoutInProgress || isFinishing()) return;

        logoutInProgress = true;

        SharedPreferences prefs =
                getSharedPreferences("AsurPrefs", MODE_PRIVATE);

        prefs.edit()
                .remove("isLoggedIn")
                .remove("expiryDate")
                .remove("encKey")
                .remove("userKey")
                .remove("serialUuid")
                .apply();

        Toast.makeText(this,
                "Logged Out: " + reason,
                Toast.LENGTH_LONG).show();

        Intent intent = new Intent(this, LoginActivity.class);
        intent.setFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK
                        | Intent.FLAG_ACTIVITY_CLEAR_TASK);

        startActivity(intent);
        finish();
    }

    private void setupBackPressHandler() {
        OnBackPressedCallback callback =
                new OnBackPressedCallback(true) {
                    @Override
                    public void handleOnBackPressed() {
                        long currentTime = System.currentTimeMillis();

                        if (currentTime - lastBackPressTime
                                < BACK_PRESS_INTERVAL) {
                            if (backToast != null) {
                                backToast.cancel();
                            }

                            finishAffinity();
                            return;
                        }

                        lastBackPressTime = currentTime;

                        if (backToast != null) {
                            backToast.cancel();
                        }

                        backToast = Toast.makeText(
                                MainActivity.this,
                                "Press back again to exit",
                                Toast.LENGTH_SHORT);

                        backToast.show();
                    }
                };

        getOnBackPressedDispatcher().addCallback(this, callback);
    }

    private void openTelegram() {
        try {
            Intent intent = new Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse(nativeBridge.getTelegramUrl()));

            startActivity(intent);

        } catch (Exception e) {
            Toast.makeText(this,
                    "Telegram app not found!",
                    Toast.LENGTH_SHORT).show();
        }
    }

    private void startExpiryTimer() {
        TextView tvExpiryDate = findViewById(R.id.tvExpiryDate);
        TextView tvDays = findViewById(R.id.tvDays);
        TextView tvHrs = findViewById(R.id.tvHrs);
        TextView tvMin = findViewById(R.id.tvMin);
        TextView tvSec = findViewById(R.id.tvSec);

        SharedPreferences prefs =
                getSharedPreferences("AsurPrefs", MODE_PRIVATE);

        long expiryTime = prefs.getLong("expiryDate", 0L);

        if (tvExpiryDate == null || tvDays == null
                || tvHrs == null || tvMin == null || tvSec == null) {
            return;
        }

        java.text.SimpleDateFormat sdf =
                new java.text.SimpleDateFormat(
                        "dd MMM yyyy",
                        java.util.Locale.getDefault());

        tvExpiryDate.setText(
                sdf.format(new java.util.Date(expiryTime)));

        timerRunnable = new Runnable() {
            @Override
            public void run() {
                long currentTime = System.currentTimeMillis();
                long timeLeft = expiryTime - currentTime;

                if (timeLeft > 0) {
                    long days = timeLeft / (1000 * 60 * 60 * 24);
                    long hours = (timeLeft / (1000 * 60 * 60)) % 24;
                    long minutes = (timeLeft / (1000 * 60)) % 60;
                    long seconds = (timeLeft / 1000) % 60;

                    tvDays.setText(String.format(
                            java.util.Locale.getDefault(), "%02d", days));
                    tvHrs.setText(String.format(
                            java.util.Locale.getDefault(), "%02d", hours));
                    tvMin.setText(String.format(
                            java.util.Locale.getDefault(), "%02d", minutes));
                    tvSec.setText(String.format(
                            java.util.Locale.getDefault(), "%02d", seconds));

                    timerHandler.postDelayed(this, 1000);
                } else {
                    tvDays.setText("00");
                    tvHrs.setText("00");
                    tvMin.setText("00");
                    tvSec.setText("00");

                    forceLogout("Key Expired!");
                }
            }
        };

        timerHandler.post(timerRunnable);
    }

    private void showStylishLoadingDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        View dialogView = getLayoutInflater().inflate(
                R.layout.dialog_loading, null);

        builder.setView(dialogView);
        builder.setCancelable(false);

        loadingDialog = builder.create();
        loadingDialog.show();

        if (loadingDialog.getWindow() != null) {
            loadingDialog.getWindow().setBackgroundDrawableResource(
                    android.R.color.transparent);
        }
    }

    private void downloadAndExtractAim() {
        if (!Shizuku.pingBinder()) {
            Toast.makeText(this,
                    "Shizuku not running! Start it first.",
                    Toast.LENGTH_LONG).show();
            return;
        }

        if (Shizuku.checkSelfPermission()
                != PackageManager.PERMISSION_GRANTED) {
            pendingDownloadAfterPermission = true;

            Shizuku.requestPermission(
                    SHIZUKU_PERMISSION_REQUEST_CODE);

            Toast.makeText(this,
                    "Allow Shizuku permission to continue.",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        showStylishLoadingDialog();

        new Thread(() -> {
            try {
                File tempZipFile =
                        new File(getCacheDir(), "AIM_online.zip");

                URL url = new URL(nativeBridge.getAimZipUrl());
                HttpURLConnection connection =
                        (HttpURLConnection) url.openConnection();

                connection.setInstanceFollowRedirects(true);
                connection.connect();

                if (connection.getResponseCode()
                        != HttpURLConnection.HTTP_OK) {
                    throw new Exception(
                            "Server Error: " + connection.getResponseCode());
                }

                try (InputStream input = connection.getInputStream();
                     FileOutputStream output =
                             new FileOutputStream(tempZipFile)) {

                    byte[] data = new byte[4096];
                    int count;

                    while ((count = input.read(data)) != -1) {
                        output.write(data, 0, count);
                    }

                    output.flush();
                } finally {
                    connection.disconnect();
                }

                File tempExtractDir =
                        new File(getCacheDir(), "aim_temp");

                if (tempExtractDir.exists()) {
                    deleteDirectory(tempExtractDir);
                }

                if (!tempExtractDir.mkdirs()
                        && !tempExtractDir.isDirectory()) {
                    throw new IOException(
                            "Could not create extraction directory");
                }

                try (ZipInputStream zis = new ZipInputStream(
                        new FileInputStream(tempZipFile))) {

                    ZipEntry entry;
                    byte[] buffer = new byte[8192];

                    while ((entry = zis.getNextEntry()) != null) {
                        File file = new File(
                                tempExtractDir, entry.getName());

                        String root = tempExtractDir.getCanonicalPath()
                                + File.separator;

                        if (!file.getCanonicalPath().startsWith(root)
                                && !file.getCanonicalPath().equals(
                                        tempExtractDir.getCanonicalPath())) {
                            throw new IOException(
                                    "Invalid ZIP entry path");
                        }

                        if (entry.isDirectory()) {
                            file.mkdirs();
                        } else {
                            File parent = file.getParentFile();

                            if (parent != null && !parent.exists()
                                    && !parent.mkdirs()) {
                                throw new IOException(
                                        "Could not create directory");
                            }

                            try (FileOutputStream fos =
                                         new FileOutputStream(file)) {
                                int len;

                                while ((len = zis.read(buffer)) > 0) {
                                    fos.write(buffer, 0, len);
                                }
                            }
                        }

                        zis.closeEntry();
                    }
                }

                String targetDir =
                        "/storage/emulated/0/Android/data/" + PKG_BGMI
                        + "/files/UE4Game/ShadowTrackerExtra/"
                        + "ShadowTrackerExtra/Saved/Paks/puffer_temp";

                int removeResult = runShizukuCommand(
                        "rm -rf \"" + targetDir + "\"");

                if (removeResult != 0) {
                    throw new IOException(
                            "Could not clear destination directory");
                }

                int mkdirResult = runShizukuCommand(
                        "mkdir -p \"" + targetDir + "\"");

                if (mkdirResult != 0) {
                    throw new IOException(
                            "Could not create destination directory");
                }

                File[] files = tempExtractDir.listFiles();

                if (files != null) {
                    for (File file : files) {
                        if (file.isFile()) {
                            copyFileViaShizuku(
                                    file,
                                    targetDir + "/" + file.getName());
                        }
                    }
                }

                runOnUiThread(() -> {
                    dismissLoadingDialog();

                    Toast.makeText(this,
                            "Download Successfully!",
                            Toast.LENGTH_LONG).show();
                });

            } catch (Exception e) {
                Log.e("file_download",
                        "Error: " + e.getMessage(), e);

                runOnUiThread(() -> {
                    dismissLoadingDialog();

                    Toast.makeText(this,
                            "Download failed! Check internet.",
                            Toast.LENGTH_LONG).show();
                });
            }
        }).start();
    }

    private void dismissLoadingDialog() {
        if (!isFinishing() && loadingDialog != null
                && loadingDialog.isShowing()) {
            loadingDialog.dismiss();
        }
    }

    private void copyFileViaShizuku(
            File localFile, String targetPath) throws Exception {

        String cmd = "cat > \"" + targetPath + "\"";

        Class<?> shizukuClass = Class.forName("rikka.shizuku.Shizuku");

        Method newProcessMethod = shizukuClass.getDeclaredMethod(
                "newProcess",
                String[].class,
                String[].class,
                String.class);

        newProcessMethod.setAccessible(true);

        Process process = (Process) newProcessMethod.invoke(
                null,
                new String[]{"sh", "-c", cmd},
                null,
                null);

        try (FileInputStream fis = new FileInputStream(localFile);
             OutputStream os = process.getOutputStream()) {

            byte[] buffer = new byte[8192];
            int len;

            while ((len = fis.read(buffer)) > 0) {
                os.write(buffer, 0, len);
            }

            os.flush();
        }

        int exitCode = process.waitFor();

        if (exitCode != 0) {
            throw new IOException(
                    "Shizuku copy failed, exit code: " + exitCode);
        }
    }

    private void deleteDirectory(File dir) {
        if (dir != null && dir.isDirectory()) {
            File[] files = dir.listFiles();

            if (files != null) {
                for (File child : files) {
                    deleteDirectory(child);
                }
            }
        }

        if (dir != null) {
            dir.delete();
        }
    }

    private int runShizukuCommand(String command) {
        try {
            Class<?> shizukuClass = Class.forName("rikka.shizuku.Shizuku");

            Method newProcessMethod = shizukuClass.getDeclaredMethod(
                    "newProcess",
                    String[].class,
                    String[].class,
                    String.class);

            newProcessMethod.setAccessible(true);

            Process process = (Process) newProcessMethod.invoke(
                    null,
                    new String[]{"sh", "-c", command},
                    null,
                    null);

            StringBuilder output = new StringBuilder();
            StringBuilder errMsg = new StringBuilder();

            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(process.getInputStream()));
                 BufferedReader errReader = new BufferedReader(
                    new InputStreamReader(process.getErrorStream()))) {

                String line;

                while ((line = reader.readLine()) != null) {
                    output.append(line).append("\n");
                }

                while ((line = errReader.readLine()) != null) {
                    errMsg.append(line).append("\n");
                }
            }

            int exitCode = process.waitFor();

            if (exitCode != 0) {
                Log.e("AIM_EXTRACT",
                        "SHIZUKU ERROR: " + errMsg);
            }

            return exitCode;

        } catch (Exception e) {
            Log.e("AIM_EXTRACT",
                    "Shizuku command failed", e);
            return -1;
        }
    }

    private void launchGame() {
        if (!android.provider.Settings.canDrawOverlays(this)) {
            Toast.makeText(this,
                    "Overlay permission required!",
                    Toast.LENGTH_LONG).show();

            Intent perm = new Intent(
                    android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));

            startActivity(perm);
            return;
        }

        String selectedPackage = getSharedPreferences(PREFS_GAME, MODE_PRIVATE)
                .getString(KEY_SELECTED_GAME, PKG_BGMI);
        Intent intent = getPackageManager()
                .getLaunchIntentForPackage(selectedPackage);

        if (intent != null) {
            showFloatingMenu();
            startActivity(intent);
        } else {
            Toast.makeText(this,
                    "Selected game is not installed! Open Select Game and choose an installed game.",
                    Toast.LENGTH_LONG).show();
        }
    }

    private void showFloatingMenu() {
        if (overlayShowing) return;

        overlayWindowManager =
                (WindowManager) getSystemService(WINDOW_SERVICE);

        overlayView = LayoutInflater.from(this).inflate(
                R.layout.floating_menu, null);

        overlayParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);

        overlayParams.gravity = Gravity.TOP | Gravity.START;
        overlayParams.x = 50;
        overlayParams.y = 150;

        overlayWindowManager.addView(overlayView, overlayParams);
        overlayShowing = true;

        ImageView logo = overlayView.findViewById(R.id.floatingLogo);
        LinearLayout panel =
                overlayView.findViewById(R.id.floatingPanel);
        TextView telegram = overlayView.findViewById(R.id.tvTelegram);
        TextView activateBtn = overlayView.findViewById(R.id.btnActivate);

        if (logo == null || panel == null
                || telegram == null || activateBtn == null) {
            hideFloatingMenu();
            return;
        }

        final float[] touchStartX = {0};
        final float[] touchStartY = {0};
        final int[] paramStartX = {0};
        final int[] paramStartY = {0};
        final boolean[] isDragging = {false};

        logo.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    paramStartX[0] = overlayParams.x;
                    paramStartY[0] = overlayParams.y;
                    touchStartX[0] = event.getRawX();
                    touchStartY[0] = event.getRawY();
                    isDragging[0] = false;
                    return true;

                case MotionEvent.ACTION_MOVE:
                    float dx = event.getRawX() - touchStartX[0];
                    float dy = event.getRawY() - touchStartY[0];

                    if (Math.abs(dx) > 8 || Math.abs(dy) > 8) {
                        isDragging[0] = true;

                        overlayParams.x = paramStartX[0] + (int) dx;
                        overlayParams.y = paramStartY[0] + (int) dy;

                        if (overlayView != null
                                && overlayWindowManager != null) {
                            overlayWindowManager.updateViewLayout(
                                    overlayView, overlayParams);
                        }
                    }
                    return true;

                case MotionEvent.ACTION_UP:
                    if (!isDragging[0]) {
                        panel.setVisibility(
                                panel.getVisibility() == View.VISIBLE
                                        ? View.GONE : View.VISIBLE);
                    }
                    return true;
            }

            return false;
        });

        final boolean[] isActivated = {false};

        activateBtn.setOnClickListener(v -> {
            if (!isActivated[0]) {
                isActivated[0] = true;
                activateBtn.setText("ACTIVATED ✓");
                activateBtn.setAlpha(0.6f);

                Toast.makeText(this,
                        "Activated!",
                        Toast.LENGTH_SHORT).show();
            } else {
                isActivated[0] = false;
                activateBtn.setText("ACTIVATE");
                activateBtn.setAlpha(1.0f);

                Toast.makeText(this,
                        "Deactivated",
                        Toast.LENGTH_SHORT).show();
            }
        });

        telegram.setOnClickListener(v -> {
            try {
                Intent i = new Intent(
                        Intent.ACTION_VIEW,
                        Uri.parse(nativeBridge.getTelegramUrl()));

                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            } catch (Exception e) {
                Toast.makeText(this,
                        "Telegram app not found!",
                        Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void hideFloatingMenu() {
        if (overlayView != null && overlayWindowManager != null) {
            try {
                overlayWindowManager.removeView(overlayView);
            } catch (Exception ignored) {
            }

            overlayView = null;
            overlayShowing = false;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        Shizuku.removeRequestPermissionResultListener(
                permissionResultListener);

        hideFloatingMenu();

        if (timerRunnable != null) {
            timerHandler.removeCallbacks(timerRunnable);
        }

        if (pingHandler != null) {
            pingHandler.removeCallbacksAndMessages(null);
        }

        if (loadingDialog != null && loadingDialog.isShowing()) {
            loadingDialog.dismiss();
        }

        if (backToast != null) {
            backToast.cancel();
        }

        binding = null;
    }
}
