package com.sxg.bypass;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.airbnb.lottie.LottieAnimationView;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import org.json.JSONObject;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class LoginActivity extends AppCompatActivity {

    private TextInputEditText etKey;
    private MaterialButton btnLogin;
    private ProgressBar progressBar;
    private TextInputLayout tilKey;

    private static final long BACK_PRESS_INTERVAL = 2000L;
    private long lastBackPressTime = 0L;
    private Toast backToast;

    private final NativeBridge nativeBridge = new NativeBridge();
    private OkHttpClient httpClient;
    private Call loginCall;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(Color.parseColor("#06030A"));
        }

        setContentView(R.layout.activity_login);
        setupBackPressHandler();

        httpClient = new OkHttpClient.Builder()
                .connectTimeout(20, TimeUnit.SECONDS)
                .readTimeout(20, TimeUnit.SECONDS)
                .build();

        // Required flow: show LoginActivity after the splash on every app launch.

        LottieAnimationView loginRobotAnim = findViewById(R.id.loginRobotAnim);
        if (loginRobotAnim != null) {
            loginRobotAnim.playAnimation();
        }

        tilKey = findViewById(R.id.tilKey);
        etKey = findViewById(R.id.etKey);
        btnLogin = findViewById(R.id.btnLogin);
        progressBar = findViewById(R.id.progressBar);

        tilKey.setEndIconOnClickListener(v -> {
            ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            if (clipboard != null && clipboard.hasPrimaryClip()) {
                ClipData clipData = clipboard.getPrimaryClip();
                if (clipData != null && clipData.getItemCount() > 0) {
                    CharSequence pasteData = clipData.getItemAt(0).getText();
                    if (pasteData != null && pasteData.toString().trim().length() > 0) {
                        etKey.setText(pasteData.toString().trim());
                        etKey.setSelection(etKey.getText().length());
                        Toast.makeText(LoginActivity.this, "Key pasted!", Toast.LENGTH_SHORT).show();
                    }
                }
            } else {
                Toast.makeText(LoginActivity.this, "Clipboard empty!", Toast.LENGTH_SHORT).show();
            }
        });

        btnLogin.setOnClickListener(v -> {
            String key = nativeBridge.normalizeLoginKey(etKey.getText() != null ? etKey.getText().toString() : "");
            if (key.isEmpty()) {
                Toast.makeText(LoginActivity.this, "Enter key first!", Toast.LENGTH_SHORT).show();
                return;
            }

            btnLogin.setVisibility(View.GONE);
            progressBar.setVisibility(View.VISIBLE);
            verifyKeyOnline(key);
        });
    }

    private void setupBackPressHandler() {
        OnBackPressedCallback callback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                long currentTime = System.currentTimeMillis();
                if (currentTime - lastBackPressTime < BACK_PRESS_INTERVAL) {
                    if (backToast != null) backToast.cancel();
                    finishAffinity();
                    return;
                }
                lastBackPressTime = currentTime;
                if (backToast != null) backToast.cancel();
                backToast = Toast.makeText(LoginActivity.this, "Press back again to exit", Toast.LENGTH_SHORT);
                backToast.show();
            }
        };
        getOnBackPressedDispatcher().addCallback(this, callback);
    }

    private void verifyKeyOnline(String enteredKey) {
        String androidId = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
        String model = Build.MODEL;
        String brand = Build.BRAND;
        
        // Keep the existing UUID.nameUUIDFromBytes algorithm exactly compatible,
        // but move HWID composition and UUID creation behind JNI.
        String uuid = nativeBridge.generateSerial(enteredKey, androidId, model, brand);

        RequestBody formBody = new FormBody.Builder()
                .add("game", "PUBG")
                .add("user_key", enteredKey)
                .add("serial", uuid)
                .build();

        Request request = new Request.Builder()
                .url(nativeBridge.getApiUrl())
                .post(formBody)
                .addHeader("Accept", "application/json")
                .addHeader("Charset", "UTF-8")
                .addHeader("User-Agent", "")
                .build();

        loginCall = httpClient.newCall(request);
        loginCall.enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    progressBar.setVisibility(View.GONE);
                    btnLogin.setVisibility(View.VISIBLE);
                    Toast.makeText(LoginActivity.this, "Network Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                String responseBody = response.body() != null ? response.body().string() : "";
                Log.d("LOGIN_DEBUG", "Response Body: " + responseBody);

                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    progressBar.setVisibility(View.GONE);
                    btnLogin.setVisibility(View.VISIBLE);

                    try {
                        JSONObject json = new JSONObject(responseBody);
                        boolean status = json.optBoolean("status", false);
                        
                        if (status) {
                            JSONObject data = json.has("data") ? json.getJSONObject("data") : json;
                            String rawExp = data.optString("EXP", data.optString("exp", ""));
                            String enc = data.optString("Enc", data.optString("enc", ""));

                            long expiryTimestamp = nativeBridge.parseExpiryMillis(rawExp);
                            if (expiryTimestamp <= 0L) {
                                // Preserve the original one-day fallback for malformed expiry values.
                                expiryTimestamp = System.currentTimeMillis() + (1L * 24 * 60 * 60 * 1000);
                            }

                            saveLoginSession(expiryTimestamp, enc, enteredKey, uuid);
                        } else {
                            String reason = json.optString("reason", "Invalid Key!");
                            Toast.makeText(LoginActivity.this, reason, Toast.LENGTH_LONG).show();
                        }
                    } catch (Exception e) {
                        Toast.makeText(LoginActivity.this, "Parse Error! Check Logcat.", Toast.LENGTH_LONG).show();
                    }
                });
            }
        });
    }

    @Override
    protected void onDestroy() {
        if (loginCall != null) {
            loginCall.cancel();
        }
        if (backToast != null) {
            backToast.cancel();
        }
        super.onDestroy();
    }

    private void saveLoginSession(long expiryTime, String encKey, String userKey, String serialUuid) {
        SharedPreferences prefs = getSharedPreferences("AsurPrefs", MODE_PRIVATE);
        
        // HomeActivity asks for the key on each launch, but this flag still
        // records that the saved key was successfully verified.
        prefs.edit()
                .putBoolean("isLoggedIn", true)
                .putLong("expiryDate", expiryTime) 
                .putString("encKey", encKey)
                .putString("userKey", userKey)       
                .putString("serialUuid", serialUuid) 
                .apply();

        Toast.makeText(LoginActivity.this, "Login successful!", Toast.LENGTH_SHORT).show();

        SharedPreferences updatedPrefs = getSharedPreferences("AsurPrefs", MODE_PRIVATE);
        boolean introShown = updatedPrefs.getBoolean("introShown", false);
        Intent nextIntent = new Intent(
                LoginActivity.this,
                introShown ? MainActivity.class : IntroActivity.class
        );
        startActivity(nextIntent);
        finish();
    }
}