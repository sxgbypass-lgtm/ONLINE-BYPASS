package com.sxg.bypass;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.PowerManager;
import android.provider.Settings;
import android.content.pm.PackageManager;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import rikka.shizuku.Shizuku;

public class SettingsActivity extends AppCompatActivity {
 @Override protected void onCreate(Bundle state) { super.onCreate(state); getWindow().setStatusBarColor(android.graphics.Color.rgb(12,8,22)); getWindow().setNavigationBarColor(android.graphics.Color.rgb(12,8,22)); setContentView(R.layout.activity_settings); wireNavigation(); }
 @Override protected void onResume() { super.onResume(); refreshStatuses(); }
 private void wireNavigation() {
  View h=findViewById(R.id.navHome), g=findViewById(R.id.navSelectGame), s=findViewById(R.id.navSetup);
  setActiveBottomNavigation(R.id.navSettings);
  if(h!=null) h.setOnClickListener(v->{startActivity(new Intent(this, MainActivity.class)); finish();});
  if(g!=null) g.setOnClickListener(v->{startActivity(new Intent(this, SelectGameActivity.class)); finish();});
  if(s!=null) s.setOnClickListener(v->{startActivity(new Intent(this, SetupActivity.class)); finish();});
 }
 private void setActiveBottomNavigation(int activeId) {
  int[] ids={R.id.navHome,R.id.navSelectGame,R.id.navSetup,R.id.navSettings};
  for(int id:ids){View item=findViewById(id);if(item==null)continue;boolean active=id==activeId;item.setBackgroundResource(active?R.drawable.bg_bottom_nav_selected:android.R.color.transparent);if(item instanceof TextView)((TextView)item).setTextColor(android.graphics.Color.parseColor(active?"#FFFFFF":"#C7B8E8"));}
 }
 private void refreshStatuses() {
  boolean overlay=Settings.canDrawOverlays(this);
  boolean shizuku=Shizuku.pingBinder() && Shizuku.checkSelfPermission()==PackageManager.PERMISSION_GRANTED;
  boolean files=Build.VERSION.SDK_INT>=Build.VERSION_CODES.R ? Environment.isExternalStorageManager() : checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE)==PackageManager.PERMISSION_GRANTED;
  PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE);
  boolean battery=Build.VERSION.SDK_INT<Build.VERSION_CODES.M || (pm!=null && pm.isIgnoringBatteryOptimizations(getPackageName()));
  bind(R.id.rowOverlay,"Display Over Other Apps","▣",overlay,()->{Intent i=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName()));startActivity(i);});
  bind(R.id.rowShizuku,"Setup Shizuku Permission","⬡",shizuku,()->{if(!Shizuku.pingBinder()){startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://play.google.com/store/apps/details?id=moe.shizuku.privileged.api")));}else if(Shizuku.checkSelfPermission()!=PackageManager.PERMISSION_GRANTED)Shizuku.requestPermission(1001);});
  bind(R.id.rowFileAccess,"Setup File Access","▤",files,()->{if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.R){Intent i=new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,Uri.parse("package:"+getPackageName()));try{startActivity(i);}catch(Exception e){startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));}}else requestPermissions(new String[]{android.Manifest.permission.READ_EXTERNAL_STORAGE,android.Manifest.permission.WRITE_EXTERNAL_STORAGE},1002);});
  bind(R.id.rowBattery,"Disable Battery Optimization","ϟ",battery,()->{if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.M&&!battery){try{startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,Uri.parse("package:"+getPackageName())));}catch(Exception e){startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));}}});
 }
 private void bind(int id,String label,String glyph,boolean granted,Runnable action){View row=findViewById(id); if(row==null)return; ((TextView)row.findViewById(R.id.permissionName)).setText(label); TextView icon=row.findViewById(R.id.permissionIcon), status=row.findViewById(R.id.permissionStatus), state=row.findViewById(R.id.permissionStateIcon); icon.setText(glyph); status.setText(granted?"Granted":"Not Granted"); int color=android.graphics.Color.parseColor(granted?"#4ADE80":"#FB7185"); status.setTextColor(color); state.setText(granted?"✓":"!"); state.setTextColor(color); row.setOnClickListener(v->action.run()); }
}
