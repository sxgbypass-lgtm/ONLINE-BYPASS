package com.sxg.bypass;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.PackageInfo;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SelectGameActivity extends AppCompatActivity {
    private static final String PREFS = "sxg_preferences";
    private static final String KEY_SELECTED_GAME = "selected_game_package";
    private static final String DEFAULT_GAME = "com.pubg.imobile";

    private final String[][] games = {
            {"BGMI Mobile (IN)", "com.pubg.imobile", "4.5.0"},
            {"PUBG Mobile (KR)", "com.pubg.krmobile", "4.5.0"},
            {"PUBG Mobile (GL)", "com.tencent.ig", "4.5.0"},
            {"PUBG Mobile (TW)", "com.rekoo.pubgm", "4.5.0"},
            {"PUBG Mobile (VNG)", "com.vng.pubgmobile", "4.5.0"},
            {"BGMI Lite (IN)", "com.krafton.bgmilite", "4.5.0"},
            {"PUBG Lite (GL)", "com.tencent.igfit", "4.5.0"}
    };

    private final int[] rowIds = {
            R.id.gameBgmiIn, R.id.gamePubgKr, R.id.gamePubgGl,
            R.id.gamePubgTw, R.id.gamePubgVng, R.id.gameBgmiLite,
            R.id.gamePubgLite
    };

    private final String[] imageNames = {
            "bgmi_in", "pubg_kr", "pubg_gl", "pubg_tw",
            "pubg_vng", "bgmi_lite", "pubg_lite"
    };

    private SharedPreferences preferences;
    private String selectedPackage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(12, 8, 22));
        getWindow().setNavigationBarColor(Color.rgb(12, 8, 22));
        setContentView(R.layout.activity_select_game);

        preferences = getSharedPreferences(PREFS, MODE_PRIVATE);
        selectedPackage = preferences.getString(KEY_SELECTED_GAME, DEFAULT_GAME);
        populateAndWireGames();
        wireNavigation();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (preferences != null) refreshGameStatusesAndSelection();
    }

    private void populateAndWireGames() {
        for (int i = 0; i < rowIds.length; i++) {
            final int index = i;
            View row = findViewById(rowIds[i]);
            if (row == null) continue;

            ((TextView) row.findViewById(R.id.gameName)).setText(games[i][0]);
            ((TextView) row.findViewById(R.id.gamePackage)).setText(games[i][1]);

            ImageView image = row.findViewById(R.id.gameImage);
            int imageRes = getResources().getIdentifier(imageNames[i], "drawable", getPackageName());
            if (imageRes != 0) image.setImageResource(imageRes);

            row.setClickable(true);
            row.setFocusable(true);
            row.setOnClickListener(v -> {
                selectedPackage = games[index][1];
                preferences.edit().putString(KEY_SELECTED_GAME, selectedPackage).apply();
                Toast.makeText(this, games[index][0] + " selected", Toast.LENGTH_SHORT).show();

                // After choosing a game, return directly to Home.
                Intent intent = new Intent(SelectGameActivity.this, MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(intent);
                finish();
            });
        }
        refreshGameStatusesAndSelection();
    }

    private void refreshGameStatusesAndSelection() {
        for (int i = 0; i < rowIds.length; i++) {
            View row = findViewById(rowIds[i]);
            if (row == null) continue;

            boolean selected = games[i][1].equals(selectedPackage);
            boolean installed = isGameInstalled(games[i][1]);

            TextView status = row.findViewById(R.id.gameInstallStatus);
            status.setText(installed ? "Installed" : "Not installed");
            status.setTextColor(installed ? Color.rgb(74, 222, 128) : Color.rgb(167, 139, 250));

            TextView version = row.findViewById(R.id.gameVersion);
            if (installed) {
                String installedVersion = getInstalledVersionName(games[i][1]);
                version.setText(installedVersion.isEmpty()
                        ? "Version: Unknown"
                        : "Version: " + installedVersion);
                version.setTextColor(Color.rgb(216, 180, 254));
            } else {
                version.setText("Version: —");
                version.setTextColor(Color.rgb(112, 95, 140));
            }

            TextView mark = row.findViewById(R.id.gameSelectionMark);
            mark.setText(selected ? "✓" : "");
            GradientDrawable markBg = new GradientDrawable();
            markBg.setShape(GradientDrawable.OVAL);
            if (selected) {
                markBg.setColor(Color.rgb(139, 92, 246));
                markBg.setStroke(dp(1), Color.rgb(196, 181, 253));
            } else {
                markBg.setColor(Color.TRANSPARENT);
                markBg.setStroke(dp(2), Color.rgb(112, 95, 140));
            }
            mark.setBackground(markBg);
            mark.setContentDescription(selected ? "Selected" : "Not selected");

            GradientDrawable rowBg = new GradientDrawable();
            rowBg.setColor(selected ? Color.rgb(43, 27, 65) : Color.rgb(29, 22, 45));
            rowBg.setCornerRadius(dp(12));
            rowBg.setStroke(dp(selected ? 2 : 1), selected
                    ? Color.rgb(139, 92, 246) : Color.rgb(56, 43, 76));
            row.setBackground(rowBg);
            row.setContentDescription(games[i][0] + (selected ? ", selected" : "")
                    + (installed ? ", installed" : ", not installed"));
        }
    }

    private boolean isGameInstalled(String packageName) {
        try {
            getPackageManager().getApplicationInfo(packageName, 0);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    private String getInstalledVersionName(String packageName) {
        try {
            PackageInfo info = getPackageManager().getPackageInfo(packageName, 0);
            String versionName = info.versionName;
            if (versionName != null && !versionName.trim().isEmpty()) {
                return versionName.trim();
            }
            if (android.os.Build.VERSION.SDK_INT >= 28) {
                return String.valueOf(info.getLongVersionCode());
            }
            // versionCode is available on the project's minimum supported Android versions.
            return String.valueOf(info.versionCode);
        } catch (PackageManager.NameNotFoundException e) {
            return "";
        }
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void wireNavigation() {
        View home = findViewById(R.id.navHome);
        View game = findViewById(R.id.navSelectGame);
        View setup = findViewById(R.id.navSetup);
        View settings = findViewById(R.id.navSettings);
        if (home != null) home.setOnClickListener(v -> go(MainActivity.class));
        if (game != null) game.setOnClickListener(v -> refreshGameStatusesAndSelection());
        if (setup != null) setup.setOnClickListener(v -> go(SetupActivity.class));
        if (settings != null) settings.setOnClickListener(v -> go(SettingsActivity.class));
        setActiveBottomNavigation(R.id.navSelectGame);
    }

    private void setActiveBottomNavigation(int activeId) {
        int[] ids = {R.id.navHome, R.id.navSelectGame, R.id.navSetup, R.id.navSettings};
        for (int id : ids) {
            View item = findViewById(id);
            if (item == null) continue;
            boolean active = id == activeId;
            item.setBackgroundResource(active ? R.drawable.bg_bottom_nav_selected : android.R.color.transparent);
            if (item instanceof TextView) {
                ((TextView) item).setTextColor(Color.parseColor(active ? "#FFFFFF" : "#C7B8E8"));
            }
        }
    }

    private void go(Class<?> activityClass) {
        startActivity(new Intent(this, activityClass));
        finish();
    }
}
