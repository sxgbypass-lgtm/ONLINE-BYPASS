package com.sxg.bypass;

import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.LinearInterpolator;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.splashscreen.SplashScreen;

import com.airbnb.lottie.LottieAnimationView;

public class HomeActivity extends AppCompatActivity {

    private final Handler navigationHandler = new Handler(Looper.getMainLooper());
    private Runnable navigationRunnable;
    private ObjectAnimator pulseAnimator;
    private ObjectAnimator progressAnimator;
    private LottieAnimationView robotAnim;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        // ✅ SplashScreen — super.onCreate() se PEHLE
        SplashScreen splashScreen = SplashScreen.installSplashScreen(this);

        super.onCreate(savedInstanceState);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(Color.parseColor("#06030A"));
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
            }
        }

        setContentView(R.layout.activity_home);

        robotAnim = findViewById(R.id.robotAnim);
        if (robotAnim != null) {
            robotAnim.playAnimation();
        }

        View featureLayout = findViewById(R.id.featureLayout);
        if (featureLayout != null) {
            pulseAnimator = ObjectAnimator.ofPropertyValuesHolder(
                    featureLayout,
                    PropertyValuesHolder.ofFloat(View.ALPHA, 0.7f, 1.0f),
                    PropertyValuesHolder.ofFloat(View.SCALE_X, 0.98f, 1.0f),
                    PropertyValuesHolder.ofFloat(View.SCALE_Y, 0.98f, 1.0f)
            );
            pulseAnimator.setDuration(1500);
            pulseAnimator.setRepeatCount(ObjectAnimator.INFINITE);
            pulseAnimator.setRepeatMode(ObjectAnimator.REVERSE);
            pulseAnimator.setInterpolator(new LinearInterpolator());
            pulseAnimator.start();
        }

        ProgressBar loadingProgress = findViewById(R.id.loadingProgress);
        if (loadingProgress != null) {
            progressAnimator = ObjectAnimator.ofInt(loadingProgress, "progress", 0, 100);
            progressAnimator.setDuration(3800);
            progressAnimator.setInterpolator(new LinearInterpolator());
            progressAnimator.start();
        }

        navigationRunnable = () -> {

            SharedPreferences prefs = getSharedPreferences("AsurPrefs", MODE_PRIVATE);
            boolean isLoggedIn = prefs.getBoolean("isLoggedIn", false);
            long expiryDate = prefs.getLong("expiryDate", 0L);
            String savedKey = prefs.getString("userKey", "");
            long currentDate = System.currentTimeMillis();

            // Clear only expired login data. Never clear onboarding state here.
            if (new NativeBridge().shouldClearHomeSession(
                    isLoggedIn, !savedKey.isEmpty(), expiryDate, currentDate)) {
                Toast.makeText(HomeActivity.this, "Key Expired!", Toast.LENGTH_LONG).show();
                prefs.edit()
                        .remove("isLoggedIn")
                        .remove("expiryDate")
                        .remove("encKey")
                        .remove("userKey")
                        .remove("serialUuid")
                        .apply();
            }

            // Required flow: splash first, then always ask for the key.
            startActivity(new Intent(HomeActivity.this, LoginActivity.class));
            finish();
        };
        navigationHandler.postDelayed(navigationRunnable, 4000);
    }

    @Override
    protected void onDestroy() {
        if (navigationRunnable != null) {
            navigationHandler.removeCallbacks(navigationRunnable);
        }
        if (pulseAnimator != null) pulseAnimator.cancel();
        if (progressAnimator != null) progressAnimator.cancel();
        if (robotAnim != null) robotAnim.cancelAnimation();
        super.onDestroy();
    }
}