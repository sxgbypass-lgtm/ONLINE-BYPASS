package com.sxg.bypass;

import android.app.Dialog;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

public class SetupActivity extends AppCompatActivity {

    private static final String VIDEO_URL =
            "https://raw.githubusercontent.com/sxgbypass-lgtm/LODAER/refs/heads/main/setup.mp4";

    private Dialog fullscreenDialog;
    private FrameLayout videoContainer;
    private Button fullscreenButton;
    private PlayerView playerView;
    private ProgressBar videoLoading;
    private ExoPlayer exoPlayer;
    private boolean shouldResumePlayback;
    private boolean isFullscreen;
    private boolean playbackErrorShown;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(0xFF0C0816);
        getWindow().setNavigationBarColor(0xFF0C0816);
        setContentView(R.layout.activity_setup);

        setupFullscreen();
        setupVideo();
        setupDownloadButton();
        wire();
    }

    private void setupFullscreen() {
        playerView = findViewById(R.id.setupPlayerView);
        videoContainer = findViewById(R.id.setupVideoContainer);
        fullscreenButton = findViewById(R.id.btnFullscreen);
        videoLoading = findViewById(R.id.videoLoading);
        fullscreenButton.setOnClickListener(v -> openFullscreen());
    }

    private void setupVideo() {
        if (videoLoading != null) videoLoading.setVisibility(View.VISIBLE);
        exoPlayer = new ExoPlayer.Builder(this).build();
        playerView.setPlayer(exoPlayer);
        playerView.setKeepContentOnPlayerReset(true);
        playerView.setShowBuffering(PlayerView.SHOW_BUFFERING_ALWAYS);
        playerView.setControllerAutoShow(true);
        playerView.setControllerHideOnTouch(true);

        exoPlayer.addListener(new Player.Listener() {
            @Override
            public void onPlaybackStateChanged(int playbackState) {
                if (videoLoading != null) {
                    videoLoading.setVisibility(
                            playbackState == Player.STATE_BUFFERING || playbackState == Player.STATE_IDLE
                                    ? View.VISIBLE : View.GONE);
                }
                if (playbackState == Player.STATE_READY) playbackErrorShown = false;
            }

            @Override
            public void onPlayerError(@NonNull PlaybackException error) {
                if (videoLoading != null) videoLoading.setVisibility(View.GONE);
                if (!playbackErrorShown && !isFinishing()) {
                    playbackErrorShown = true;
                    Toast.makeText(SetupActivity.this,
                            "Video load nahi hui. Internet ya video URL check karo.",
                            Toast.LENGTH_LONG).show();
                }
            }
        });

        exoPlayer.setMediaItem(MediaItem.fromUri(Uri.parse(VIDEO_URL)));
        exoPlayer.prepare();
        exoPlayer.setPlayWhenReady(true);
    }

    private void setupDownloadButton() {
        Button download = findViewById(R.id.btnDownloadShizuku);
        download.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(
                    "https://play.google.com/store/apps/details?id=moe.shizuku.privileged.api"));
            try {
                startActivity(intent);
            } catch (Exception e) {
                Toast.makeText(this, "Play Store open nahi ho saka.", Toast.LENGTH_LONG).show();
            }
        });
    }

    private void openFullscreen() {
        if (isFullscreen || playerView == null || exoPlayer == null) return;
        if (playerView.getParent() instanceof ViewGroup) {
            ((ViewGroup) playerView.getParent()).removeView(playerView);
        }

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);

        fullscreenDialog = new Dialog(this);
        fullscreenDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(Color.BLACK);
        frame.addView(playerView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        Button exitButton = new Button(this);
        exitButton.setText("✕");
        exitButton.setTextSize(22);
        exitButton.setTextColor(Color.WHITE);
        exitButton.setBackgroundTintList(ColorStateList.valueOf(0x99000000));
        FrameLayout.LayoutParams exitParams = new FrameLayout.LayoutParams(dp(52), dp(52), Gravity.TOP | Gravity.END);
        exitParams.setMargins(dp(8), dp(8), dp(8), dp(8));
        frame.addView(exitButton, exitParams);
        exitButton.setOnClickListener(v -> closeFullscreen());

        fullscreenDialog.setContentView(frame);
        fullscreenDialog.setOnDismissListener(d -> restoreVideo());
        fullscreenDialog.show();

        Window window = fullscreenDialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawableResource(android.R.color.black);
            window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
            window.getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }
        isFullscreen = true;
    }

    private void closeFullscreen() {
        if (fullscreenDialog != null && fullscreenDialog.isShowing()) fullscreenDialog.dismiss();
    }

    private void restoreVideo() {
        if (playerView != null && playerView.getParent() instanceof ViewGroup) {
            ((ViewGroup) playerView.getParent()).removeView(playerView);
        }
        if (videoContainer != null && playerView != null) {
            videoContainer.addView(playerView, 0, new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        }
        isFullscreen = false;
        fullscreenDialog = null;
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void wire() {
        View h = findViewById(R.id.navHome);
        View g = findViewById(R.id.navSelectGame);
        View p = findViewById(R.id.navSettings);
        setActiveBottomNavigation(R.id.navSetup);
        if (h != null) h.setOnClickListener(v -> go(MainActivity.class));
        if (g != null) g.setOnClickListener(v -> go(SelectGameActivity.class));
        if (p != null) p.setOnClickListener(v -> go(SettingsActivity.class));
    }

    private void setActiveBottomNavigation(int activeId) {
        int[] ids = {R.id.navHome, R.id.navSelectGame, R.id.navSetup, R.id.navSettings};
        for (int id : ids) {
            View item = findViewById(id);
            if (item == null) continue;
            boolean active = id == activeId;
            item.setBackgroundResource(active ? R.drawable.bg_bottom_nav_selected : android.R.color.transparent);
            if (item instanceof TextView) {
                ((TextView) item).setTextColor(Color.parseColor(active ? "#FFFFFF" : "#C7B8E8"));
            }
        }
    }

    private void go(Class<?> c) {
        releasePlayer();
        startActivity(new Intent(this, c));
        finish();
    }

    @Override
    public void onBackPressed() {
        if (fullscreenDialog != null && fullscreenDialog.isShowing()) closeFullscreen();
        else super.onBackPressed();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (exoPlayer != null) {
            shouldResumePlayback = exoPlayer.getPlayWhenReady();
            exoPlayer.pause();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (exoPlayer != null && shouldResumePlayback) {
            exoPlayer.play();
            shouldResumePlayback = false;
        }
    }

    @Override
    protected void onDestroy() {
        releasePlayer();
        super.onDestroy();
    }

    private void releasePlayer() {
        if (exoPlayer != null) {
            if (playerView != null) playerView.setPlayer(null);
            exoPlayer.release();
            exoPlayer = null;
        }
    }
}
