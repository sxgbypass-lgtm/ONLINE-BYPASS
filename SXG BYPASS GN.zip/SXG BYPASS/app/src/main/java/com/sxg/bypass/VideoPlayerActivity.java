
package com.sxg.bypass;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.MediaController;
import android.widget.VideoView;
import android.widget.Toast;

public class VideoPlayerActivity extends Activity {

    private static final String VIDEO_URL =
        "https://raw.githubusercontent.com/sxgbypass-lgtm/LODAER/refs/heads/main/setup.mp4";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setStatusBarColor(0xFF000000);
        getWindow().setNavigationBarColor(0xFF000000);

        setContentView(R.layout.activity_video_player);

        VideoView videoView = findViewById(R.id.videoView);

        MediaController controls = new MediaController(this);
        controls.setAnchorView(videoView);

        videoView.setMediaController(controls);
        videoView.setVideoURI(Uri.parse(VIDEO_URL));

        videoView.setOnPreparedListener(player -> {
            videoView.start();
            controls.show();
        });

        videoView.setOnErrorListener((player, what, extra) -> {
            Toast.makeText(
                this,
                "Video load nahi hui. Internet aur video URL check karo.",
                Toast.LENGTH_LONG
            ).show();
            return true;
        });
    }
}
