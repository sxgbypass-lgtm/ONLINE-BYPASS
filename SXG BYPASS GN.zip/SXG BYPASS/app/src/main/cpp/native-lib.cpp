#include <jni.h>
#include <string>
#include <ctime>
#include <sstream>
#include <iomanip>
#include "obfuscate.h"

// Compile-time XOR obfuscation. URLs are decoded only when their JNI getter runs.
// This hides plain URL literals from a simple strings scan, but is not encryption.

extern "C" JNIEXPORT jstring JNICALL
Java_com_sxg_bypass_NativeBridge_getApiUrl(JNIEnv* env, jobject thiz) {
    return env->NewStringUTF(OBFUSCATE("https://kuro-api.cv/ASURPVT/connect"));
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_sxg_bypass_NativeBridge_getAimZipUrl(JNIEnv* env, jobject thiz) {
    return env->NewStringUTF(OBFUSCATE("https://github.com/sxgbypass-lgtm/ONLINE-BYPASS/releases/download/SXG/AIM.zip"));
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_sxg_bypass_NativeBridge_getTelegramUrl(JNIEnv* env, jobject thiz) {
    return env->NewStringUTF(OBFUSCATE("https://t.me/GODxOFFICAIL"));
}

// Parses the existing server expiry format yyyy-MM-dd HH:mm:ss in device local time.
// Returns 0 for invalid input; Java preserves the existing fallback behavior.
extern "C" JNIEXPORT jlong JNICALL
Java_com_sxg_bypass_NativeBridge_parseExpiryMillis(JNIEnv* env, jobject thiz, jstring value) {
    if (!value) return 0;
    const char* chars = env->GetStringUTFChars(value, nullptr);
    if (!chars) return 0;
    std::tm tm{};
    std::istringstream input(chars);
    input >> std::get_time(&tm, "%Y-%m-%d %H:%M:%S");
    bool ok = !input.fail();
    env->ReleaseStringUTFChars(value, chars);
    if (!ok) return 0;
    tm.tm_isdst = -1;
    std::time_t seconds = std::mktime(&tm);
    if (seconds == static_cast<std::time_t>(-1)) return 0;
    return static_cast<jlong>(seconds) * 1000LL;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_sxg_bypass_NativeBridge_isSessionExpired(JNIEnv* env, jobject thiz, jlong expiryMillis, jlong nowMillis) {
    return (expiryMillis <= 0 || nowMillis >= expiryMillis) ? JNI_TRUE : JNI_FALSE;
}


// Keep small, deterministic business decisions in native code. These are not
// security boundaries; the server remains authoritative for key validation.
extern "C" JNIEXPORT jstring JNICALL
Java_com_sxg_bypass_NativeBridge_normalizeLoginKey(JNIEnv* env, jobject thiz, jstring value) {
    if (!value) return env->NewStringUTF("");
    const char* chars = env->GetStringUTFChars(value, nullptr);
    if (!chars) return env->NewStringUTF("");
    std::string result(chars);
    env->ReleaseStringUTFChars(value, chars);
    size_t first = result.find_first_not_of(" \t\r\n\f\v");
    if (first == std::string::npos) result.clear();
    else {
        size_t last = result.find_last_not_of(" \t\r\n\f\v");
        result = result.substr(first, last - first + 1);
        for (char &c : result) if (c >= 'a' && c <= 'z') c = static_cast<char>(c - 'a' + 'A');
    }
    return env->NewStringUTF(result.c_str());
}

// Preserve Java UUID.nameUUIDFromBytes(byte[]) semantics while moving the
// HWID composition and serial-generation entry point behind JNI. Calling the
// platform UUID implementation avoids changing the server-facing serial format.
extern "C" JNIEXPORT jstring JNICALL
Java_com_sxg_bypass_NativeBridge_generateSerial(JNIEnv* env, jobject thiz,
                                                jstring key, jstring androidId,
                                                jstring model, jstring brand) {
    auto getUtf = [&](jstring value) -> std::string {
        if (!value) return std::string();
        const char* chars = env->GetStringUTFChars(value, nullptr);
        if (!chars) return std::string();
        std::string out(chars);
        env->ReleaseStringUTFChars(value, chars);
        return out;
    };
    std::string raw = getUtf(key) + getUtf(androidId) + getUtf(model) + getUtf(brand);
    jclass uuidClass = env->FindClass("java/util/UUID");
    if (!uuidClass) return nullptr;
    jmethodID nameUuid = env->GetStaticMethodID(uuidClass, "nameUUIDFromBytes", "([B)Ljava/util/UUID;");
    jmethodID toString = env->GetMethodID(uuidClass, "toString", "()Ljava/lang/String;");
    if (!nameUuid || !toString) { env->DeleteLocalRef(uuidClass); return nullptr; }
    jbyteArray bytes = env->NewByteArray(static_cast<jsize>(raw.size()));
    if (!bytes) { env->DeleteLocalRef(uuidClass); return nullptr; }
    if (!raw.empty()) env->SetByteArrayRegion(bytes, 0, static_cast<jsize>(raw.size()), reinterpret_cast<const jbyte*>(raw.data()));
    jobject uuid = env->CallStaticObjectMethod(uuidClass, nameUuid, bytes);
    jstring result = uuid ? static_cast<jstring>(env->CallObjectMethod(uuid, toString)) : nullptr;
    if (uuid) env->DeleteLocalRef(uuid);
    env->DeleteLocalRef(bytes);
    env->DeleteLocalRef(uuidClass);
    return result;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_sxg_bypass_NativeBridge_shouldClearHomeSession(JNIEnv* env, jobject thiz, jboolean loggedIn, jboolean hasKey, jlong expiryMillis, jlong nowMillis) {
    return (loggedIn == JNI_TRUE && hasKey == JNI_TRUE && expiryMillis > 0 && nowMillis >= expiryMillis) ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_sxg_bypass_NativeBridge_shouldRedirectIntro(JNIEnv* env, jobject thiz, jboolean introShown, jboolean freshLaunch) {
    return (introShown == JNI_TRUE && freshLaunch == JNI_TRUE) ? JNI_TRUE : JNI_FALSE;
}
