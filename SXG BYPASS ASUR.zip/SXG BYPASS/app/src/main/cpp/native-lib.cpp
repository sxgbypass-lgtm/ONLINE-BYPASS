
#include <jni.h>

extern "C"
JNIEXPORT jstring JNICALL
Java_com_sxg_bypass_NativeBridge_stringFromJNI(
        JNIEnv* env, jobject thiz) {
    return env->NewStringUTF("SXG BYPASS C++ is working");
}
