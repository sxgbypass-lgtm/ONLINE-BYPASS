
package com.sxg.bypass;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.PixelFormat;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.sxg.bypass.databinding.ActivityMainBinding;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.TimeUnit;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import rikka.shizuku.Shizuku;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;

    private static final int SHIZUKU_PERMISSION_REQUEST_CODE = 1001;
    private static final String TELEGRAM_URL = "https://t.me/GODxOFFICAIL";
    private static final String AIM_ZIP_URL = "https://github.com/sxgbypass-lgtm/ONLINE-BYPASS/releases/download/SXG/AIM.zip";
    private static final String PKG_BGMI = "com.pubg.imobile";

    private static final String API_URL = "https://kuro-api.cv/ASURPVT/connect";
    private OkHttpClient httpClient;
    private Handler pingHandler;

    private WindowManager overlayWindowManager;
    private View overlayView;
    private WindowManager.LayoutParams overlayParams;
    private boolean overlayShowing = false;
    private AlertDialog loadingDialog;

    private Handler timerHandler = new Handler(Looper.getMainLooper());
    private Runnable timerRunnable;

    private boolean pendingDownloadAfterPermission = false;
    private boolean logoutInProgress = false;

    private static final long BACK_PRESS_INTERVAL = 2000L;
    private long lastBackPressTime = 0L;
    private Toast backToast;

    private final Shizuku.OnRequestPermissionResultListener permissionResultListener =
            (requestCode, grantResult) -> {
                if (requestCode == SHIZUKU_PERMISSION_REQUEST_CODE) {
                    runOnUiThread(() -> {
                        if (grantResult == PackageManager.PERMISSION_GRANTED) {
                            Toast.makeText(this, "Shizuku permission granted!",
                                    Toast.LENGTH_SHORT).show();

                            if (pendingDownloadAfterPermission) {
                                pendingDownloadAfterPermission = false;
                                downloadAndExtractAim();
                            }
                        } else {
                            pendingDownloadAfterPermission = false;
                            Toast.makeText(this,
                                    "Permission denied! Allow in Shizuku.",
                                    Toast.LENGTH_LONG).show();
                        }
                    });
                }
            };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        SharedPreferences prefs =
                getSharedPreferences("AsurPrefs", MODE_PRIVATE);

        String savedKey = prefs.getString("userKey", "");
        long savedExpiry = prefs.getLong("expiryDate", 0L);

        boolean sessionExpired = savedExpiry <= 0L
                || System.currentTimeMillis() >= savedExpiry;

        if (savedKey.isEmpty() || sessionExpired) {
            if (!savedKey.isEmpty() && sessionExpired) {
                prefs.edit()
                        .remove("isLoggedIn")
                        .remove("expiryDate")
                        .remove("encKey")
                        .remove("userKey")
                        .remove("serialUuid")
                        .apply();

                Toast.makeText(this,
                        "Key Expired! Please login again.",
                        Toast.LENGTH_LONG).show();
            }

            Intent loginIntent = new Intent(this, LoginActivity.class);
            loginIntent.addFlags(
                    Intent.FLAG_ACTIVITY_CLEAR_TOP
                            | Intent.FLAG_ACTIVITY_NEW_TASK);

            startActivity(loginIntent);
            finish();
            return;
        }

        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // C++ JNI test: calls the native function from libsxg.so.
        try {
            NativeBridge bridge = new NativeBridge();
            String result = bridge.stringFromJNI();

            Log.d("SXG_NATIVE", result);
            Toast.makeText(this, result, Toast.LENGTH_LONG).show();

        } catch (Exception | UnsatisfiedLinkError e) {
            Log.e("SXG_NATIVE", "JNI test failed", e);
            Toast.makeText(this,
                    "C++ JNI test failed!",
                    Toast.LENGTH_LONG).show();
        }

        setupBackPressHandler();

        binding.btnLaunch.setOnClickListener(v -> launchGame());
        binding.btnAimAssist.setOnClickListener(v -> downloadAndExtractAim());

        View btnTelegramIcon = findViewById(R.id.btnTelegramIcon);
        if (btnTelegramIcon != null) {
            btnTelegramIcon.setOnClickListener(v -> openTelegram());
        }

        Shizuku.addRequestPermissionResultListener(permissionResultListener);

        startExpiryTimer();

        httpClient = new OkHttpClient.Builder()
                .connectTimeout(15, TimeUnit.SECONDS)
                .readTimeout(15, TimeUnit.SECONDS)
                .build();

        startHeartbeat();
    }

    private void startHeartbeat() {
        pingHandler = new Handler(Looper.getMainLooper());

        Runnable pingRunnable = new Runnable() {
            @Override
            public void run() {
                checkServerStatus();
                pingHandler.postDelayed(this, 3 * 60 * 1000);
            }
        };

        pingHandler.postDelayed(pingRunnable, 10000);
    }

    private void checkServerStatus() {
        SharedPreferences prefs =
                getSharedPreferences("AsurPrefs", MODE_PRIVATE);

        String userKey = prefs.getString("userKey", "");
        String serialUuid = prefs.getString("serialUuid", "");

        if (userKey.isEmpty() || serialUuid.isEmpty()) return;

        RequestBody formBody = new FormBody.Builder()
                .add("game", "PUBG")
                .add("user_key", userKey)
                .add("serial", serialUuid)
                .build();

        Request request = new Request.Builder()
                .url(API_URL)
                .post(formBody)
                .addHeader("Accept", "application/json")
                .addHeader("Charset", "UTF-8")
                .addHeader("User-Agent", "")
                .build();

        httpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(
                    @NonNull Call call,
                    @NonNull IOException e) {
                Log.e("HEARTBEAT",
                        "Network Error: " + e.getMessage());
            }

            @Override
            public void onResponse(
                    @NonNull Call call,
                    @NonNull Response response) throws IOException {

                String responseBody = response.body() != null
                        ? response.body().string()
                        : "";

                runOnUiThread(() -> {
                    try {
                        JSONObject json = new JSONObject(responseBody);
                        boolean status = json.optBoolean("status", false);

                        if (!status) {
                            String reason = json.optString(
                                    "reason",
                                    "Your key has been blocked by Admin!");

                            forceLogout(reason);
                        } else {
                            JSONObject data = json.has("data")
                                    ? json.getJSONObject("data")
                                    : json;

                            String rawExp = data.optString("EXP", "");

                            if (!rawExp.isEmpty()) {
                                try {
                                    java.text.SimpleDateFormat sdf =
                                            new java.text.SimpleDateFormat(
                                                    "yyyy-MM-dd HH:mm:ss",
                                                    java.util.Locale.US);

                                    java.util.Date date = sdf.parse(rawExp);

                                    if (date != null) {
                                        prefs.edit()
                                                .putLong("expiryDate",
                                                        date.getTime())
                                                .apply();
                                    }
                                } catch (Exception ignored) {
                                }
                            }
                        }
                    } catch (Exception e) {
                        Log.e("HEARTBEAT",
                                "Parse Error: " + responseBody);
                    }
                });
            }
        });
    }

    private void forceLogout(String reason) {
        if (logoutInProgress || isFinishing()) return;

        logoutInProgress = true;

        SharedPreferences prefs =
                getSharedPreferences("AsurPrefs", MODE_PRIVATE);

        prefs.edit()
                .remove("isLoggedIn")
                .remove("expiryDate")
                .remove("encKey")
                .remove("userKey")
                .remove("serialUuid")
                .apply();

        Toast.makeText(this,
                "Logged Out: " + reason,
                Toast.LENGTH_LONG).show();

        Intent intent = new Intent(this, LoginActivity.class);
        intent.setFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK
                        | Intent.FLAG_ACTIVITY_CLEAR_TASK);

        startActivity(intent);
        finish();
    }

    private void setupBackPressHandler() {
        OnBackPressedCallback callback =
                new OnBackPressedCallback(true) {
                    @Override
                    public void handleOnBackPressed() {
                        long currentTime = System.currentTimeMillis();

                        if (currentTime - lastBackPressTime
                                < BACK_PRESS_INTERVAL) {
                            if (backToast != null) backToast.cancel();
                            finishAffinity();
                            return;
                        }

                        lastBackPressTime = currentTime;

                        if (backToast != null) backToast.cancel();

                        backToast = Toast.makeText(
                                MainActivity.this,
                                "Press back again to exit",
                                Toast.LENGTH_SHORT);

                        backToast.show();
                    }
                };

        getOnBackPressedDispatcher().addCallback(this, callback);
    }

    private void openTelegram() {
        try {
            Intent intent = new Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse(TELEGRAM_URL));

            startActivity(intent);

        } catch (Exception e) {
            Toast.makeText(this,
                    "Telegram app not found!",
                    Toast.LENGTH_SHORT).show();
        }
    }

    private void startExpiryTimer() {
        TextView tvExpiryDate = findViewById(R.id.tvExpiryDate);
        TextView tvDays = findViewById(R.id.tvDays);
        TextView tvHrs = findViewById(R.id.tvHrs);
        TextView tvMin = findViewById(R.id.tvMin);
        TextView tvSec = findViewById(R.id.tvSec);

        SharedPreferences prefs =
                getSharedPreferences("AsurPrefs", MODE_PRIVATE);

        long expiryTime = prefs.getLong("expiryDate", 0);

        if (tvExpiryDate == null) return;

        java.text.SimpleDateFormat sdf =
                new java.text.SimpleDateFormat(
                        "dd MMM yyyy",
                        java.util.Locale.getDefault());

        tvExpiryDate.setText(
                sdf.format(new java.util.Date(expiryTime)));

        timerRunnable = new Runnable() {
            @Override
            public void run() {
                long currentTime = System.currentTimeMillis();
                long timeLeft = expiryTime - currentTime;

                if (timeLeft > 0) {
                    long days = timeLeft / (1000 * 60 * 60 * 24);
                    long hours = (timeLeft / (1000 * 60 * 60)) % 24;
                    long minutes = (timeLeft / (1000 * 60)) % 60;
                    long seconds = (timeLeft / 1000) % 60;

                    tvDays.setText(String.format("%02d", days));
                    tvHrs.setText(String.format("%02d", hours));
                    tvMin.setText(String.format("%02d", minutes));
                    tvSec.setText(String.format("%02d", seconds));

                    timerHandler.postDelayed(this, 1000);
                } else {
                    tvDays.setText("00");
                    tvHrs.setText("00");
                    tvMin.setText("00");
                    tvSec.setText("00");

                    forceLogout("Key Expired!");
                }
            }
        };

        timerHandler.post(timerRunnable);
    }

    private void showStylishLoadingDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        View dialogView = getLayoutInflater().inflate(
                R.layout.dialog_loading, null);

        builder.setView(dialogView);
        builder.setCancelable(false);

        loadingDialog = builder.create();

        if (loadingDialog.getWindow() != null) {
            loadingDialog.getWindow().setBackgroundDrawableResource(
                    android.R.color.transparent);
        }

        loadingDialog.show();
    }

    private void downloadAndExtractAim() {
        if (!Shizuku.pingBinder()) {
            Toast.makeText(this,
                    "Shizuku not running! Start it first.",
                    Toast.LENGTH_LONG).show();
            return;
        }

        if (Shizuku.checkSelfPermission()
                != PackageManager.PERMISSION_GRANTED) {
            pendingDownloadAfterPermission = true;

            Shizuku.requestPermission(
                    SHIZUKU_PERMISSION_REQUEST_CODE);

            Toast.makeText(this,
                    "Allow Shizuku permission to continue.",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        showStylishLoadingDialog();

        new Thread(() -> {
            try {
                File tempZipFile =
                        new File(getCacheDir(), "AIM_online.zip");

                URL url = new URL(AIM_ZIP_URL);
                HttpURLConnection connection =
                        (HttpURLConnection) url.openConnection();

                connection.setInstanceFollowRedirects(true);
                connection.connect();

                if (connection.getResponseCode()
                        != HttpURLConnection.HTTP_OK) {
                    throw new Exception(
                            "Server Error: " + connection.getResponseCode());
                }

                try (InputStream input = connection.getInputStream();
                     FileOutputStream output =
                             new FileOutputStream(tempZipFile)) {

                    byte[] data = new byte[4096];
                    int count;

                    while ((count = input.read(data)) != -1) {
                        output.write(data, 0, count);
                    }

                    output.flush();
                } finally {
                    connection.disconnect();
                }

                File tempExtractDir =
                        new File(getCacheDir(), "aim_temp");

                if (tempExtractDir.exists()) {
                    deleteDirectory(tempExtractDir);
                }

                tempExtractDir.mkdirs();

                try (ZipInputStream zis = new ZipInputStream(
                        new FileInputStream(tempZipFile))) {

                    ZipEntry entry;
                    byte[] buffer = new byte[8192];

                    while ((entry = zis.getNextEntry()) != null) {
                        File file = new File(
                                tempExtractDir, entry.getName());

                        // Reject ZIP entries that escape the extraction folder.
                        String root = tempExtractDir.getCanonicalPath()
                                + File.separator;

                        if (!file.getCanonicalPath().startsWith(root)
                                && !file.getCanonicalPath().equals(
                                        tempExtractDir.getCanonicalPath())) {
                            throw new IOException(
                                    "Invalid ZIP entry path");
                        }

                        if (entry.isDirectory()) {
                            file.mkdirs();
                        } else {
                            File parent = file.getParentFile();
                            if (parent != null) parent.mkdirs();

                            try (FileOutputStream fos =
                                         new FileOutputStream(file)) {
                                int len;
                                while ((len = zis.read(buffer)) > 0) {
                                    fos.write(buffer, 0, len);
                                }
                            }
                        }

                        zis.closeEntry();
                    }
                }

                String targetDir =
                        "/storage/emulated/0/Android/data/" + PKG_BGMI
                        + "/files/UE4Game/ShadowTrackerExtra/"
                        + "ShadowTrackerExtra/Saved/Paks/puffer_temp";

                runShizukuCommand("rm -rf \"" + targetDir + "\"");
                runShizukuCommand("mkdir -p \"" + targetDir + "\"");

                File[] files = tempExtractDir.listFiles();

                if (files != null) {
                    for (File file : files) {
                        if (file.isFile()) {
                            copyFileViaShizuku(
                                    file,
                                    targetDir + "/" + file.getName());
                        }
                    }
                }

                new Handler(Looper.getMainLooper()).post(() -> {
                    if (loadingDialog != null
                            && loadingDialog.isShowing()) {
                        loadingDialog.dismiss();
                    }

                    Toast.makeText(this,
                            "Download Successfully!",
                            Toast.LENGTH_LONG).show();
                });

            } catch (Exception e) {
                Log.e("file_download",
                        "Error: " + e.getMessage(), e);

                new Handler(Looper.getMainLooper()).post(() -> {
                    if (loadingDialog != null
                            && loadingDialog.isShowing()) {
                        loadingDialog.dismiss();
                    }

                    Toast.makeText(this,
                            "Download failed! Check internet.",
                            Toast.LENGTH_LONG).show();
                });
            }
        }).start();
    }

    private void copyFileViaShizuku(
            File localFile, String targetPath) throws Exception {

        String cmd = "cat > \"" + targetPath + "\"";

        Class<?> shizukuClass = Class.forName("rikka.shizuku.Shizuku");

        Method newProcessMethod = shizukuClass.getDeclaredMethod(
                "newProcess",
                String[].class,
                String[].class,
                String.class);

        newProcessMethod.setAccessible(true);

        Process process = (Process) newProcessMethod.invoke(
                null,
                new String[]{"sh", "-c", cmd},
                null,
                null);

        try (FileInputStream fis = new FileInputStream(localFile);
             OutputStream os = process.getOutputStream()) {

            byte[] buffer = new byte[8192];
            int len;

            while ((len = fis.read(buffer)) > 0) {
                os.write(buffer, 0, len);
            }

            os.flush();
        }

        int exitCode = process.waitFor();

        if (exitCode != 0) {
            throw new IOException(
                    "Shizuku copy failed, exit code: " + exitCode);
        }
    }

    private void deleteDirectory(File dir) {
        if (dir != null && dir.isDirectory()) {
            File[] files = dir.listFiles();

            if (files != null) {
                for (File child : files) {
                    deleteDirectory(child);
                }
            }
        }

        if (dir != null) dir.delete();
    }

    private int runShizukuCommand(String command) {
        try {
            Class<?> shizukuClass = Class.forName("rikka.shizuku.Shizuku");

            Method newProcessMethod = shizukuClass.getDeclaredMethod(
                    "newProcess",
                    String[].class,
                    String[].class,
                    String.class);

            newProcessMethod.setAccessible(true);

            Process process = (Process) newProcessMethod.invoke(
                    null,
                    new String[]{"sh", "-c", command},
                    null,
                    null);

            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(process.getInputStream()));

            String line;

            while ((line = reader.readLine()) != null) {
                // Consume command output.
            }

            BufferedReader errReader = new BufferedReader(
                    new InputStreamReader(process.getErrorStream()));

            StringBuilder errMsg = new StringBuilder();

            while ((line = errReader.readLine()) != null) {
                errMsg.append(line).append("\n");
            }

            int exitCode = process.waitFor();

            if (exitCode != 0 && errMsg.length() > 0) {
                Log.e("AIM_EXTRACT",
                        "SHIZUKU ERROR: " + errMsg);
            }

            return exitCode;

        } catch (Exception e) {
            Log.e("AIM_EXTRACT",
                    "Shizuku command failed", e);
            return -1;
        }
    }

    private void launchGame() {
        if (!android.provider.Settings.canDrawOverlays(this)) {
            Toast.makeText(this,
                    "Overlay permission required!",
                    Toast.LENGTH_LONG).show();

            Intent perm = new Intent(
                    android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));

            startActivity(perm);
            return;
        }

        Intent intent = getPackageManager()
                .getLaunchIntentForPackage(PKG_BGMI);

        if (intent != null) {
            showFloatingMenu();
            startActivity(intent);
        } else {
            Toast.makeText(this,
                    "Game not installed!",
                    Toast.LENGTH_SHORT).show();
        }
    }

    private void showFloatingMenu() {
        if (overlayShowing) return;

        overlayWindowManager =
                (WindowManager) getSystemService(WINDOW_SERVICE);

        overlayView = LayoutInflater.from(this).inflate(
                R.layout.floating_menu, null);

        overlayParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);

        overlayParams.gravity = Gravity.TOP | Gravity.START;
        overlayParams.x = 50;
        overlayParams.y = 150;

        overlayWindowManager.addView(overlayView, overlayParams);
        overlayShowing = true;

        ImageView logo = overlayView.findViewById(R.id.floatingLogo);
        LinearLayout panel =
                overlayView.findViewById(R.id.floatingPanel);
        TextView telegram = overlayView.findViewById(R.id.tvTelegram);
        TextView activateBtn = overlayView.findViewById(R.id.btnActivate);

        final float[] touchStartX = {0};
        final float[] touchStartY = {0};
        final int[] paramStartX = {0};
        final int[] paramStartY = {0};
        final boolean[] isDragging = {false};

        logo.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        paramStartX[0] = overlayParams.x;
                        paramStartY[0] = overlayParams.y;
                        touchStartX[0] = event.getRawX();
                        touchStartY[0] = event.getRawY();
                        isDragging[0] = false;
                        return true;

                    case MotionEvent.ACTION_MOVE:
                        float dx = event.getRawX() - touchStartX[0];
                        float dy = event.getRawY() - touchStartY[0];

                        if (Math.abs(dx) > 8 || Math.abs(dy) > 8) {
                            isDragging[0] = true;

                            overlayParams.x =
                                    paramStartX[0] + (int) dx;
                            overlayParams.y =
                                    paramStartY[0] + (int) dy;

                            overlayWindowManager.updateViewLayout(
                                    overlayView, overlayParams);
                        }
                        return true;

                    case MotionEvent.ACTION_UP:
                        if (!isDragging[0]) {
                            panel.setVisibility(
                                    panel.getVisibility() == View.VISIBLE
                                            ? View.GONE : View.VISIBLE);
                        }
                        return true;
                }

                return false;
            }
        });

        final boolean[] isActivated = {false};

        activateBtn.setOnClickListener(v -> {
            if (!isActivated[0]) {
                isActivated[0] = true;
                activateBtn.setText("ACTIVATED ✓");
                activateBtn.setAlpha(0.6f);

                Toast.makeText(this,
                        "Activated!",
                        Toast.LENGTH_SHORT).show();
            } else {
                isActivated[0] = false;
                activateBtn.setText("ACTIVATE");
                activateBtn.setAlpha(1.0f);

                Toast.makeText(this,
                        "Deactivated",
                        Toast.LENGTH_SHORT).show();
            }
        });

        telegram.setOnClickListener(v -> {
            Intent i = new Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse(TELEGRAM_URL));

            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        });
    }

    private void hideFloatingMenu() {
        if (overlayView != null && overlayWindowManager != null) {
            try {
                overlayWindowManager.removeView(overlayView);
            } catch (Exception ignored) {
            }

            overlayView = null;
            overlayShowing = false;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        Shizuku.removeRequestPermissionResultListener(
                permissionResultListener);

        hideFloatingMenu();

        if (timerHandler != null && timerRunnable != null) {
            timerHandler.removeCallbacks(timerRunnable);
        }

        if (pingHandler != null) {
            pingHandler.removeCallbacksAndMessages(null);
        }

        if (backToast != null) backToast.cancel();

        binding = null;
    }
}
