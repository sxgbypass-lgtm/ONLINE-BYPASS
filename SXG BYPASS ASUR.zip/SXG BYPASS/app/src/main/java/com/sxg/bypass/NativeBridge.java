package com.sxg.bypass;

public class NativeBridge {
    static {
        System.loadLibrary("sxg");
    }

    public native String stringFromJNI();
}
